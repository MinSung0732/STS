
package com.minsung.dto;

import lombok.Data;

@Data
public class Names {

    public Language language;
    public String name;

}
