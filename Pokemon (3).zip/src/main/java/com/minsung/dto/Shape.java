
package com.minsung.dto;

import lombok.Data;

@Data
public class Shape {

    public String name;
    public String url;

}
