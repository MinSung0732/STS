
package com.minsung.dto;

import java.util.List;

import lombok.Data;

@Data
public class Chain {

    public List<Object> evolutionDetails;
    public List<EvolvesTo> evolvesTo;
    public Boolean isBaby;
    public Species__2 species;

}
