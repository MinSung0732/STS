
package com.minsung.dto;

import lombok.Data;

@Data
public class Habitat {

    public String name;
    public String url;

}
