
package com.minsung.dto;

import lombok.Data;

@Data
public class Pokemon {

    public String name;
    public String url;

}
