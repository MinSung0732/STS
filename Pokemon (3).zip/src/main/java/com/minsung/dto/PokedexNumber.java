
package com.minsung.dto;

import lombok.Data;

@Data
public class PokedexNumber {

    public Integer entry_number;
    public Pokedex pokedex;

}
