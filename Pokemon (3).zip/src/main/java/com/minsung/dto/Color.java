
package com.minsung.dto;

import lombok.Data;

@Data
public class Color {

    public String name;
    public String url;

}
