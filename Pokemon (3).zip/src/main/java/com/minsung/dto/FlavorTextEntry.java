
package com.minsung.dto;

import lombok.Data;

@Data
public class FlavorTextEntry {

    public String flavor_text;
    public Language language;
    public Version version;

}
