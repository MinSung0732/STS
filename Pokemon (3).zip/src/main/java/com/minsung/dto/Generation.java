
package com.minsung.dto;

import lombok.Data;

@Data
public class Generation {

    public String name;
    public String url;

}
