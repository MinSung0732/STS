package com.minsung.dto;

import lombok.Data;

@Data
public class Result {
    public String name;
    public String url;
    
    public String getId() {
        // 예시: url이 항상 "https://pokeapi.co/api/v2/pokemon/{id}/" 형태라고 가정
        String[] parts = url.split("/");
        return parts[parts.length - 1];
    }
}
