
package com.minsung.dto;

import java.util.List;

import lombok.Data;

@Data
public class EvolvesTo {

    public List<EvolutionDetail> evolutionDetails;
    public List<EvolvesTo__1> evolvesTo;
    public Boolean isBaby;
    public Species__1 species;

}
