
package com.minsung.dto;

import lombok.Data;

@Data
public class PalParkEncounter {

    public Area area;
    public Integer baseScore;
    public Integer rate;

}
