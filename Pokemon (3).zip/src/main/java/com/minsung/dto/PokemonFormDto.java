
package com.minsung.dto;

import java.util.List;

import lombok.Data;

@Data
public class PokemonFormDto {

    public String formName;
    public List<Object> formNames;
    public Integer formOrder;
    public Integer id;
    public Boolean isBattleOnly;
    public Boolean isDefault;
    public Boolean isMega;
    public String name;
    public List<Object> names;
    public Integer order;
    public Pokemon pokemon;
    public Sprites sprites;
    public List<Type> types;
    public VersionGroup versionGroup;

}
