
package com.minsung.dto;

import lombok.Data;

@Data
public class EvolutionDto {

    public Object babyTriggerItem;
    public Chain chain;
    public Integer id;

}
