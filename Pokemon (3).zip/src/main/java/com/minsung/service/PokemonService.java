package com.minsung.service;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.minsung.abilDto.AbilityDto;
import com.minsung.dto.PokemonDto;
import com.minsung.dto.PokemonFormDto;
import com.minsung.maindto.PokemonMainDto;

@Service
//@AllArgsConstructor
public class PokemonService {

	@Cacheable("pokemonInfoCache")
	public PokemonDto getPokeInfo(String pokemonNameOrId) {
		String speciesUrl = "https://pokeapi.co/api/v2/pokemon-species/";
		String apiUrl = speciesUrl + pokemonNameOrId + "/";
		URI uri = null;
		try {
			uri = new URI(apiUrl);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		RestTemplate restTemplate = new RestTemplate();
		PokemonDto pokemonDto = restTemplate.getForObject(uri, PokemonDto.class);

		return pokemonDto;
	}

	@Cacheable("pokemonFormCache")
	public PokemonFormDto getFormInfo(String pokemonNameOrId) {
		String speciesUrl = "https://pokeapi.co/api/v2/pokemon-form/";
		String apiUrl = speciesUrl + pokemonNameOrId + "/";
		URI uri = null;
		try {
			uri = new URI(apiUrl);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		RestTemplate restTemplate = new RestTemplate();
		PokemonFormDto pokemon = restTemplate.getForObject(uri, PokemonFormDto.class);

		return pokemon;
	}
	
	@Cacheable("pokemonStatCache")
	public PokemonMainDto getStat(String pokemonNameOrId) {
		String speciesUrl = "https://pokeapi.co/api/v2/pokemon/";
		String apiUrl = speciesUrl + pokemonNameOrId + "/";
		URI uri = null;
		try {
			uri = new URI(apiUrl);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		RestTemplate restTemplate = new RestTemplate();
		PokemonMainDto pokemon = restTemplate.getForObject(uri, PokemonMainDto.class);

		return pokemon;
	}
	
	@Cacheable("pokemonAbilCache")
	public AbilityDto getAbility(String abilityNameOrId) {
		String speciesUrl = "https://pokeapi.co/api/v2/ability/";
		String apiUrl = speciesUrl + abilityNameOrId + "/";
		URI uri = null;
		try {
			uri = new URI(apiUrl);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		RestTemplate restTemplate = new RestTemplate();
		AbilityDto ability = restTemplate.getForObject(uri, AbilityDto.class);

		return ability;
	}
	
	
}
