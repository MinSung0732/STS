package com.minsung.mapper;

import org.springframework.stereotype.Repository;

@Repository
public interface PokemonMapper {

}
