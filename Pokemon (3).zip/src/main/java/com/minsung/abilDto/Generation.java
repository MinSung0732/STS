
package com.minsung.abilDto;

import lombok.Data;

@Data
public class Generation {

    public String name;
    public String url;

}
