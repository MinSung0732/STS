package com.minsung.abilDto;

import lombok.Data;

@Data
public class Pokemon {

    public Boolean is_hidden;
    public Pokemon__1 pokemon;
    public Integer slot;

}
