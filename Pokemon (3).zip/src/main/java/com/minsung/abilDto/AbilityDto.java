
package com.minsung.abilDto;

import java.util.List;

import lombok.Data;

@Data
public class AbilityDto {

    public List<EffectChange> effectChanges;
    public List<EffectEntry__1> effectEntries;
    public List<FlavorTextEntry> flavor_text_entries;
    public Generation generation;
    public Integer id;
    public Boolean isMainSeries;
    public String name;
    public List<Name> names;
    public List<Pokemon> pokemon;

}
