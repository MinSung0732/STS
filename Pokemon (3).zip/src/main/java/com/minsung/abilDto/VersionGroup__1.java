package com.minsung.abilDto;

import lombok.Data;

@Data
public class VersionGroup__1 {

    public String name;
    public String url;

}
