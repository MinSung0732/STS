
package com.minsung.maindto;

import lombok.Data;

@Data
public class GameIndex {

    public Integer gameIndex;
    public Version version;

}
