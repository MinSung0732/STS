
package com.minsung.maindto;

import lombok.Data;

@Data
public class Cries {

    public String latest;
    public String legacy;

}
