
package com.minsung.maindto;

import lombok.Data;

@Data
public class GenerationV {

    public BlackWhite blackWhite;

}
