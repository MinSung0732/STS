
package com.minsung.maindto;

import lombok.Data;

@Data
public class Species {

    public String name;
    public String url;

}
