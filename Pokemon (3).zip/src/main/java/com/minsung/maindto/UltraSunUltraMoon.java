
package com.minsung.maindto;

import lombok.Data;

@Data
public class UltraSunUltraMoon {

    public String frontDefault;
    public Object frontFemale;
    public String frontShiny;
    public Object frontShinyFemale;

}
