
package com.minsung.maindto;

import lombok.Data;

@Data
public class OmegarubyAlphasapphire {

    public String frontDefault;
    public Object frontFemale;
    public String frontShiny;
    public Object frontShinyFemale;

}
