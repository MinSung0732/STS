
package com.minsung.maindto;

import lombok.Data;

@Data
public class OfficialArtwork {

    public String frontDefault;
    public String frontShiny;

}
