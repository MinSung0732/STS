
package com.minsung.maindto;

import lombok.Data;

@Data
public class DreamWorld {

    public String frontDefault;
    public Object frontFemale;

}
