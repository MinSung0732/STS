
package com.minsung.maindto;

import lombok.Data;

@Data
public class GenerationVii {

    public Icons icons;
    public UltraSunUltraMoon ultraSunUltraMoon;

}
