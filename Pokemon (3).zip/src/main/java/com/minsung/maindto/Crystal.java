
package com.minsung.maindto;

import lombok.Data;

@Data
public class Crystal {

    public String backDefault;
    public String backShiny;
    public String backShinyTransparent;
    public String backTransparent;
    public String frontDefault;
    public String frontShiny;
    public String frontShinyTransparent;
    public String frontTransparent;

}
