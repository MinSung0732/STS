
package com.minsung.maindto;

import lombok.Data;

@Data
public class Ability {

    public Ability__1 ability;
    public Boolean is_hidden;
    public Integer slot;

}
