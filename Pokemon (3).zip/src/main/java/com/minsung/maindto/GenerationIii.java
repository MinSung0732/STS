
package com.minsung.maindto;

import lombok.Data;

@Data
public class GenerationIii {

    public Emerald emerald;
    public FireredLeafgreen fireredLeafgreen;
    public RubySapphire rubySapphire;

}
