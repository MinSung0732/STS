
package com.minsung.maindto;

import lombok.Data;

@Data
public class Other {

    public DreamWorld dreamWorld;
    public Home home;
    public OfficialArtwork officialArtwork;
    public Showdown showdown;

}
