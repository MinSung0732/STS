
package com.minsung.maindto;

import lombok.Data;

@Data
public class Icons__1 {

    public String frontDefault;
    public Object frontFemale;

}
