
package com.minsung.maindto;

import lombok.Data;

@Data
public class Ability__1 {

    public String name;
    public String url;

}
