package com.minsung.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.minsung.abilDto.AbilityDto;
import com.minsung.service.PokemonService;

import lombok.AllArgsConstructor;

//@ResponseBody + @Controller
@RestController
@RequestMapping("/dictionary")
@AllArgsConstructor
public class PokemonRestController {

		private PokemonService service;
		
		// 특성 정보 불러오기
		@GetMapping("/ability")
		public Map<String,Object> ability(@RequestParam("name") String name, Model model) {

			AbilityDto rsAbilInfo = service.getAbility(name);

			Map<String, Object> result = new HashMap<String, Object>();
			
			if(rsAbilInfo != null) {
				result.put("result", "success");
				result.put("abilInfo", rsAbilInfo);
			} else {
				result.put("result", "fail");
			}
			
			return result;
		}
}
