
package com.minsung.dto;

import lombok.Data;

@Data
public class Genera {

    public String genus;
    public Language__1 language;

}
