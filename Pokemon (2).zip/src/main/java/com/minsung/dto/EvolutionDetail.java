
package com.minsung.dto;

import lombok.Data;

@Data
public class EvolutionDetail {

	public Object gender;
	public Object heldItem;
	public Object item;
	public Object knownMove;
	public Object knownMoveType;
	public Object location;
	public Object minAffection;
	public Object minBeauty;
	public Object minHappiness;
	public Integer minLevel;
	public Boolean needsOverworldRain;
	public Object partySpecies;
	public Object partyType;
	public Object relativePhysicalStats;
	public String timeOfDay;
	public Object tradeSpecies;
	public Trigger trigger;
	public Boolean turnUpsideDown;

}
