
package com.minsung.dto;

import lombok.Data;

@Data
public class GrowthRate {

    public String name;
    public String url;

}
