
package com.minsung.dto;

import lombok.Data;

@Data
public class Sprites {

    public String back_default;
    public Object backFemale;
    public String backShiny;
    public Object backShinyFemale;
    public String frontDefault;
    public Object frontFemale;
    public String frontShiny;
    public Object frontShinyFemale;

}
