
package com.minsung.dto;

import lombok.Data;

@Data
public class Variety {

    public Boolean isDefault;
    public Pokemon pokemon;

}
