
package com.minsung.dto;

import java.util.List;

import lombok.Data;

@Data
public class PokemonDto {

    public Integer baseHappiness;
    public Integer captureRate;
    public Color color;
    public List<EggGroup> eggGroups;
    public EvolutionChain evolutionChain;
    public Object evolvesFromSpecies;
    public List<FlavorTextEntry> flavor_text_entries;
    public List<Object> formDescriptions;
    public Boolean formsSwitchable;
    public Integer genderRate;
    public List<Genera> genera;
    public Generation generation;
    public GrowthRate growthRate;
    public Habitat habitat;
    public Boolean hasGenderDifferences;
    public Integer hatchCounter;
    public Integer id;
    public Boolean isBaby;
    public Boolean isLegendary;
    public Boolean isMythical;
    public String name;
    public List<Names> names;
    public Integer order;
    public List<PalParkEncounter> palParkEncounters;
    public List<PokedexNumber> pokedex_numbers;
    public Shape shape;
    public List<Variety> varieties;
    public Integer count;
    public String next;
    public Object previous;
    public List<Result> results;
}
