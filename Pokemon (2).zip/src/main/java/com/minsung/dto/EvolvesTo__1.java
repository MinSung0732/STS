
package com.minsung.dto;

import java.util.List;

import lombok.Data;

@Data
public class EvolvesTo__1 {

    public List<EvolutionDetail__1> evolutionDetails;
    public List<Object> evolvesTo;
    public Boolean isBaby;
    public Species species;

}
