
package com.minsung.dto;

import lombok.Data;

@Data
public class Pokedex {

    public String name;
    public String url;

}
