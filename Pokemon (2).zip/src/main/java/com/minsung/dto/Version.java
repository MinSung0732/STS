
package com.minsung.dto;

import lombok.Data;

@Data	
public class Version {

    public String name;
    public String url;

}
