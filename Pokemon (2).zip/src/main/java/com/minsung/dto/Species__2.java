
package com.minsung.dto;

import lombok.Data;

@Data
public class Species__2 {

    public String name;
    public String url;

}
