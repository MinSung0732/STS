
package com.minsung.dto;

import lombok.Data;

@Data
public class Trigger__1 {

    public String name;
    public String url;

}
