
package com.minsung.dto;

import lombok.Data;

@Data
public class Language__2 {

    public String name;
    public String url;

}
