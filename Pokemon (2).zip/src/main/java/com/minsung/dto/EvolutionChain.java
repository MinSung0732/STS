
package com.minsung.dto;

import lombok.Data;

@Data
public class EvolutionChain {

    public String url;

}
