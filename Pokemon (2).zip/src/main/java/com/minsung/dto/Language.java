
package com.minsung.dto;

import lombok.Data;

@Data
public class Language {

    public String name;
    public String url;

}
