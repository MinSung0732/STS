
package com.minsung.maindto;

import lombok.Data;

@Data
public class Yellow {

    public String backDefault;
    public String backGray;
    public String backTransparent;
    public String frontDefault;
    public String frontGray;
    public String frontTransparent;

}
