
package com.minsung.maindto;

import java.util.List;

import lombok.Data;

@Data
public class PokemonMainDto {

    public List<Ability> abilities;
    public Integer baseExperience;
    public Cries cries;
    public List<Form> forms;
    public List<GameIndex> gameIndices;
    public Integer height;
    public List<Object> heldItems;
    public Integer id;
    public Boolean isDefault;
    public String locationAreaEncounters;
    public String name;
    public Integer order;
    public List<Object> pastAbilities;
    public List<Object> pastTypes;
    public Species species;
    public Sprites sprites;
    public List<Stat> stats;
    public List<Type> types;
    public Integer weight;

}
