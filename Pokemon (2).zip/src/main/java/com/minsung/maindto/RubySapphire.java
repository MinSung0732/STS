
package com.minsung.maindto;

import lombok.Data;

@Data
public class RubySapphire {

    public String backDefault;
    public String backShiny;
    public String frontDefault;
    public String frontShiny;

}
