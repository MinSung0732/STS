
package com.minsung.maindto;

import lombok.Data;

@Data
public class Type {

    public Integer slot;
    public Type__1 type;

}
