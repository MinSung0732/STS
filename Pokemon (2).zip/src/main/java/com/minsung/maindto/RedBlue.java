
package com.minsung.maindto;

import lombok.Data;

@Data
public class RedBlue {

    public String backDefault;
    public String backGray;
    public String backTransparent;
    public String frontDefault;
    public String frontGray;
    public String frontTransparent;

}
