
package com.minsung.maindto;

import lombok.Data;

@Data
public class GenerationI {

    public RedBlue redBlue;
    public Yellow yellow;

}
