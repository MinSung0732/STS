
package com.minsung.maindto;

import lombok.Data;

@Data
public class Stat {

    public Integer base_stat;
    public Integer effort;
    public Stat__1 stat;

}
