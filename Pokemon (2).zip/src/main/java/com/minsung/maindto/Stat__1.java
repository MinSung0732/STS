
package com.minsung.maindto;

import lombok.Data;

@Data
public class Stat__1 {

    public String name;
    public String url;

}
