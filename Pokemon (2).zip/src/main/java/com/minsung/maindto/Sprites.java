
package com.minsung.maindto;

import lombok.Data;

@Data
public class Sprites {

    public String backDefault;
    public Object backFemale;
    public String backShiny;
    public Object backShinyFemale;
    public String frontDefault;
    public Object frontFemale;
    public String frontShiny;
    public Object frontShinyFemale;
    public Other other;
    public Versions versions;

}
