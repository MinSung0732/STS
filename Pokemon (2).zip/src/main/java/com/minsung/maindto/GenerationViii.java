
package com.minsung.maindto;

import lombok.Data;

@Data
public class GenerationViii {

    public Icons__1 icons;

}
