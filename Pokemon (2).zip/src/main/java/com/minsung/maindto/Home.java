
package com.minsung.maindto;

import lombok.Data;

@Data
public class Home {

    public String frontDefault;
    public Object frontFemale;
    public String frontShiny;
    public Object frontShinyFemale;

}
