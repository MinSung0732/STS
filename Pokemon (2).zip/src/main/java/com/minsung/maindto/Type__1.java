
package com.minsung.maindto;

import lombok.Data;

@Data
public class Type__1 {

    public String name;
    public String url;

}
