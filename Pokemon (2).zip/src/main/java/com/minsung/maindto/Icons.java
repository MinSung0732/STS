
package com.minsung.maindto;

import lombok.Data;

@Data
public class Icons {

    public String frontDefault;
    public Object frontFemale;

}
