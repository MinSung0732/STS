
package com.minsung.maindto;

import lombok.Data;

@Data
public class Form {

    public String name;
    public String url;

}
