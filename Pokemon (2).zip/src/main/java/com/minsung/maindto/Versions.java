
package com.minsung.maindto;

import lombok.Data;

@Data
public class Versions {

    public GenerationI generationI;
    public GenerationIi generationIi;
    public GenerationIii generationIii;
    public GenerationIv generationIv;
    public GenerationV generationV;
    public GenerationVi generationVi;
    public GenerationVii generationVii;
    public GenerationViii generationViii;

}
