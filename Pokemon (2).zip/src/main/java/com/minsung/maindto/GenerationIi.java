
package com.minsung.maindto;

import lombok.Data;

@Data
public class GenerationIi {

    public Crystal crystal;
    public Gold gold;
    public Silver silver;

}
