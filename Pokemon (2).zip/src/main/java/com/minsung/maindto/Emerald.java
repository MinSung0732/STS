
package com.minsung.maindto;

import lombok.Data;

@Data
public class Emerald {

    public String frontDefault;
    public String frontShiny;

}
