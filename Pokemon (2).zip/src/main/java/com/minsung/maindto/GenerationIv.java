
package com.minsung.maindto;

import lombok.Data;

@Data
public class GenerationIv {

    public DiamondPearl diamondPearl;
    public HeartgoldSoulsilver heartgoldSoulsilver;
    public Platinum platinum;

}
