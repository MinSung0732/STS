package com.minsung.abilDto;

import lombok.Data;

@Data
public class Language__3 {

    public String name;
    public String url;

}
