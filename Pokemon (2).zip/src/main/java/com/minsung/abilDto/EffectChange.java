
package com.minsung.abilDto;

import java.util.List;

import lombok.Data;

@Data
public class EffectChange {

    public List<EffectEntry> effectEntries;
    public VersionGroup versionGroup;

}
