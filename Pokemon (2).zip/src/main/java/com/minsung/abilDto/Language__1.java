package com.minsung.abilDto;

import lombok.Data;

@Data
public class Language__1 {

    public String name;
    public String url;

}
