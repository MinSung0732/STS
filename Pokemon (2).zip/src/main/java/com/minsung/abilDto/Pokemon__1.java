package com.minsung.abilDto;

import lombok.Data;

@Data
public class Pokemon__1 {

    public String name;
    public String url;

}
