
package com.minsung.abilDto;

import lombok.Data;

@Data
public class EffectEntry__1 {

    public String effect;
    public Language__1 language;
    public String shortEffect;

}
