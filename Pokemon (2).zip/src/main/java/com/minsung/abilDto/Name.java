package com.minsung.abilDto;

import lombok.Data;

@Data
public class Name {

    public Language__3 language;
    public String name;

}
