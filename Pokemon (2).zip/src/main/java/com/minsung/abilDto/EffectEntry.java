package com.minsung.abilDto;

import lombok.Data;

@Data
public class EffectEntry {

    public String effect;
    public Language language;

}
