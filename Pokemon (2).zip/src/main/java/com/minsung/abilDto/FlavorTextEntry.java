package com.minsung.abilDto;

import lombok.Data;

@Data
public class FlavorTextEntry {

    public String flavor_text;
    public Language__2 language;
    public VersionGroup__1 version_group;

}
