package com.minsung.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.minsung.abilDto.AbilityDto;
import com.minsung.dto.PokemonDto;
import com.minsung.dto.PokemonFormDto;
import com.minsung.dto.Result;
import com.minsung.maindto.PokemonMainDto;
import com.minsung.service.PokemonService;

import lombok.AllArgsConstructor;

@RequestMapping("/dictionary")
@AllArgsConstructor
@Controller
public class PokemonController {

	private PokemonService service;

	// 포켓몬 목록 불러오기
	@GetMapping("/dictionary")
	public String dictionary(Model model, @RequestParam("offset") int offset, @RequestParam("limit") int limit) {
		String API_URL = "https://pokeapi.co/api/v2/pokemon/?offset=" + offset + "&limit=" + limit;

		URI uri = null;
		try {
			uri = new URI(API_URL);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		RestTemplate restTemplate = new RestTemplate();
		PokemonDto result = restTemplate.getForObject(uri, PokemonDto.class);

		List<Result> pokeresult = result.getResults();
		List<PokemonDto> pokemonList = new ArrayList<>();
		List<PokemonFormDto> rsFormInfo = new ArrayList<PokemonFormDto>();

		for (Result pokemon : pokeresult) {
			String id = pokemon.getId();
			PokemonDto pokemonDto = service.getPokeInfo(id);
			PokemonFormDto FormInfo = service.getFormInfo(id);
			rsFormInfo.add(FormInfo);
			pokemonList.add(pokemonDto);
		}
		model.addAttribute("formInfo", rsFormInfo);
		model.addAttribute("pokemonList", pokemonList);
		model.addAttribute("offset", offset);
		model.addAttribute("limit", limit);

		return "dictionary/dictionary";
	}

	// 포켓몬 정보 불러오기
	@GetMapping("/species")
	public String species(Model model, @RequestParam("name") String name, @RequestParam("offset") int offset,
			@RequestParam("limit") int limit) {

		PokemonDto rsPokeInfo = service.getPokeInfo(name);
		PokemonFormDto rsFormInfo = service.getFormInfo(name);
		PokemonMainDto rsMainInfo = service.getStat(name);

		model.addAttribute("pokeInfo", rsPokeInfo);
		model.addAttribute("formInfo", rsFormInfo);
		model.addAttribute("mainInfo", rsMainInfo);
		model.addAttribute("offset", offset);
		model.addAttribute("limit", limit);
		return "dictionary/species";
	}
	
	@GetMapping("/abilityinfo")
	public String abilityInfo(@RequestParam("name") String name, Model model) {
		
		AbilityDto rsAbInfo = service.getAbility(name);
		
		model.addAttribute("abInfo", rsAbInfo);
		
		return "dictionary/abilityinfo";
	}
	
//	@GetMapping("/search")
//	public String saerch(@RequestParam("name") String name, @RequestParam("offset") int offset, @RequestParam("limit") int limit, Model model) {
//		
//		PokemonDto rsPokeInfo = null;
//		String ib = null;
//		
//		for(int i=0; i >= 897; i++) {
//			ib = ib.toString();
//			rsPokeInfo = service.getPokeInfo(ib);
//			if(rsPokeInfo.names[i].
//				
//			}
//		}
	}
	
	